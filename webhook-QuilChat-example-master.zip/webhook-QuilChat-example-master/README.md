# webhook-QuilChat-example
This is webhook example code for made a bot chat integrated with QuilChat WhatsApp Gateway

# This Api works with ChatGPT and you can use it to automate your WhatsApp with Response from ChatGPT
To do this, kindly edit the index.php to effect your OpenAI API key.

# To train this webhook kindly supply your information in Training section of the index.php

To manke this work, you'll need to host his code on your own server and then put the url in the webhook section of https://wa.quilchat.com
Then you are good to go.

# Thank you for using QuilChat.
